import 'expo/dev-client';
import { registerRootComponent } from 'expo';
import App from './src/App';
registerRootComponent(App);
